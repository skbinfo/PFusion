README

SSL/TLS binding for Tcl
TLS provides a replacement socket command for
setting up and using secure sockets.

This is a collection of binaries for the main platforms.
At runtime, the right binary library will be used.

Based on tcltls 1.7.16

tls 1.7.12  linux-x32  extracted from ActiveTcl-8.5.19.8519-i686-linux-glibc-2.5-403583.tar.gz
tls 1.7.16  linux-x64  extracted from ActiveTcl-8.6.8.0-x86_64-linux-glibc-2.5.tar.gz
tls 1.7.16  macos-x64  extracted from ActiveTcl-8.6.8.0-macosx10.9-x86_64.pkg
tls 1.7.16  win-x32                  -- from http://www.bawt.tcl3d.org
tls 1.7.16  win3-x64                 -- from http://www.bawt.tcl3d.org

tls source source code is hosted on  https://core.tcl.tk/tcltls/