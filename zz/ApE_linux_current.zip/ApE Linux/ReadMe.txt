
See instructions for installing Tcl/Tk on linux:
https://tkdocs.com/tutorial/install.html#install-x11-tcl

In short, you should be able to do:
apt install tk8.6

cd to the ApE Linux folder that you downloaded, then:
/usr/bin/wish8.6 AppMain.tcl